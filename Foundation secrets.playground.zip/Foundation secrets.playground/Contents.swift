import UIKit
import Foundation

let string = "I write for https://swiftbook.ru and my phone numbers are +79133019883 and 84352349385 and +7-(934)-555-34-24 and 8 974 113 71 54."
let range = NSRange(0..<string.count)

let types: NSTextCheckingResult.CheckingType = [.link,.phoneNumber]
let dataDatector = try NSDataDetector(types: types.rawValue)
dataDatector.enumerateMatches(in: string, options: [], range: range) { (match, _, _) in
    switch match?.resultType {
    case .link?:
        print(match?.url)
    case .phoneNumber?:
        print(match?.phoneNumber)
    default:
        return
    }
    
}
